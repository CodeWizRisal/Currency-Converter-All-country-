chrome.runtime.onInstalled.addListener(() => {
console.log("Currency converter successfully installed")
});